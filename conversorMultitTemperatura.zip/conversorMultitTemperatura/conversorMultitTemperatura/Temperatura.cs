﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace conversorMultitTemperatura
{
    internal class Temperatura
    {
        //Atibutos
        private double gradosC;
        private double gradosF;
        private double gradosK;

        //Metodo Constructor    
        public Temperatura() { }

        //Metodo set
        public void setGradosC(double gradosC)
        {
            if (gradosC < CERO_ABSOLUTO)
            {
                MessageBox.Show("La temperatura no puede ser menor que el cero absoluto.");
            }
            else
            {
                this.gradosC = gradosC;
            }
        }

        //Metodo Get
        public double getgradosC()
        {
            return this.gradosC;
        }
        public double getgradosF()
        {
            return this.gradosF;
        }
        public double getgradosK()
        {
            return this.gradosK;
        }

        //Metodo de conversion
        public void convertirC(double gradosC)
        {
            this.gradosF = (this.gradosC * 9 / 5) + 32;
            this.gradosK = this.gradosC + 273.15;
        }
        public const double CERO_ABSOLUTO = -273.15;

    }
}