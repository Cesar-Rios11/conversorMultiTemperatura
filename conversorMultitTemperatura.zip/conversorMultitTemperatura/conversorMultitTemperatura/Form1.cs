﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace conversorMultitTemperatura
{
    public partial class Form1 : Form
    {
        Temperatura temperatura = new Temperatura();
        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox2.Text = "";
            label9.Text = "00.00";
            label8.Text = "00.00";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                MessageBox.Show("Ingrese los Grados °C para convertirlos");
                textBox2.Focus();
                return;
            }
            try
            {
                double setgradosC = Convert.ToDouble(textBox2.Text);
                if (setgradosC < -273.15)
                {
                    MessageBox.Show("LA TEMPERATURA NO PUEDE SER MENOR A -273.15 °C");
                    textBox2.Focus();
                    return;
                }
                temperatura.setGradosC(setgradosC);
                temperatura.convertirC(setgradosC);
                label9.Text = temperatura.getgradosF().ToString("N2") + " °F";
                label8.Text = temperatura.getgradosK().ToString("N2") + " K";
            }
            catch (FormatException)
            {
                MessageBox.Show("Ingrese un valor numérico válido");
                textBox2.Focus();
                return;
            }

        }
    }
}